/*
  EGGX / ProCALL  version 0.80
                     eggxlib.h
 */

#ifndef _EGGXLIB_H
#define _EGGXLIB_H

#include <eggx_base.h>
#include <eggx_color.h>

#define eggx_tclr() clsc_()
#define eggx_gcloseall() gcloseall_()

#endif	/* _EGGXLIB_H */
